﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Security.Permissions;
using System.ServiceModel;
using SQLiteManager.WebService;
namespace DynamicWebServiceCall
{
    /// <summary>
    /// 웹서비스 동적 호출
    /// </summary>
    public class CallWebService
    {
        public CallWebService()
        {

        }
        private ChannelFactory<SQLWebService> channel { get; set; }
        public SQLWebService Call(string webServiceUrl)
        {
            channel = new ChannelFactory<SQLWebService>
                (
                    new WSHttpBinding(SecurityMode.Message),
                    new EndpointAddress(webServiceUrl)
                );
            SQLWebService webservice = channel.CreateChannel();
            return webservice;
        }
    }
}
