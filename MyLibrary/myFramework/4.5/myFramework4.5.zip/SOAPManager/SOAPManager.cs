﻿using SOAP.Conf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using SOAP.SOAPFactiry;
using SOAP.SOAPFactiry.WinForm;
namespace SOAP
{
    /// <summary>
    /// 비동기 작업중 예외 발생시 이를 호출한 쪽에 알려주기 위함
    /// </summary>
    /// <param name="ex">예외객체</param>
    public delegate void deleErrReporter(Exception ex);
    public class SOAPManager
    {
        #region 생성자 및 초기화
        /// <summary>
        /// 비동기 작업중에 발생한 예외를 호출한 쪽에 알려줌
        /// </summary>
        private  deleErrReporter errReporter { get; set; }
        private ISOAPFactory SOAPFactory { get; set; }
        //private static SOAPManager instance { get; set; }
        #region 서비스할 객체를 싱글톤 객체로 받는 경우
        public SOAPManager(SOAPServerType soap_server, object service, ServiceBindingType bindType, deleErrReporter errReporter)
        {
            this.errReporter = errReporter;
            switch (soap_server)
            {
                case SOAPServerType.winform:
                    SOAPFactory = new soap_WinFormFactory(bindType, service, new deleErrReporter(ThrowErr));
                    break;
                case SOAPServerType.WAS:
                    break;
                case SOAPServerType.iis:
                    break;
                default:
                    break;
            }
        }
        #endregion
        #region 서비스할 객체를 타입으로 받는 경우
        public SOAPManager(SOAPServerType soap_server, Type serviceType, ServiceBindingType bindType, deleErrReporter errReporter)
        {
            this.errReporter = errReporter;
            switch (soap_server)
            {
                case SOAPServerType.winform:
                    SOAPFactory = new soap_WinFormFactory(bindType, serviceType, new deleErrReporter(ThrowErr));
                    break;
                case SOAPServerType.WAS:
                    break;
                case SOAPServerType.iis:
                    break;
                default:
                    break;
            }
        } 
        #endregion
        #endregion

        /// <summary>
        /// SOAP서비스 시작하기
        /// 서비스로 객체를 등록했는지, 타입을 등록했는지는 자동으로 인식해서 처리
        /// </summary>
        /// <param name="serviceURL"></param>
        /// <param name="NameSpace"></param>
        public void StartSOAPService(string serviceURL,string NameSpace) 
        {
            SOAPFactory.CreateService(new Uri(serviceURL),NameSpace);
        }

        /// <summary>
        /// 현재 생성된 ServiceHost객체를 삭제하고 
        /// 다시 생성
        /// </summary>
        /// <param name="server_url"></param>
        /// <param name="NameSpace"></param>
        /// <param name="bindType"></param>
        /// <param name="service">
        /// 서비스로 제공할 객체의 타입(싱글톤 객체는 불가)
        /// </param>
        public void ChangeService(Uri server_url, string NameSpace, ServiceBindingType bindType, Type service) 
        {
            SOAPFactory.ChangeService( server_url,  NameSpace,  bindType,  service);
        }

        /// <summary>
        /// 현재 생성된 ServiceHost객체를 삭제하고
        /// 다시 생성
        /// </summary>
        /// <param name="server_url"></param>
        /// <param name="NameSpace"></param>
        /// <param name="bindType"></param>
        /// <param name="service">
        ///  서비스로 제공할 객체(싱글톤 객체)
        /// </param>
        public void ChangeService(Uri server_url, string NameSpace, ServiceBindingType bindType, object service)
        {
            SOAPFactory.ChangeService(server_url, NameSpace, bindType, service);
        }
        /// <summary>
        /// SOAP서비스 끝내기
        /// </summary>
        public  void EndSOAPService() 
        {
            if (SOAPFactory!=null)
            {
                SOAPFactory.Dispose();
            }          
        }
        public  void ThrowErr(Exception ex)
        {
            this.errReporter(ex);
        }
    }
}
