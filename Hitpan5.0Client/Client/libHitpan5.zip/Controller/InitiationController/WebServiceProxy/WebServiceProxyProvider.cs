﻿using libHitpan5.Controller.WebServiceController;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace libHitpan5.Controller.InitiationController.WebServiceProxy
{
    public class WebServiceProxyProvider
    {
        #region 인증방식에 따른 프로퍼티들
        ///// <summary>
        ///// MessageCredentialType이 UserName일때
        ///// </summary>
        //internal string serverUserID { get; set; }
        ///// <summary>
        ///// MessageCredentialType이 UserName일때
        ///// </summary>
        //internal string serverUserPassword { get; set; }
        #endregion



        private WebServiceProxyController webserviceController { get; set; }
        public WebServiceProxyProvider(WebServiceProxyController webserviceController)
        {
            this.webserviceController = webserviceController;
        }

        public ISQLWebService GetWebServiceProxy() 
        {
            ISQLWebService proxy = webserviceController.GetWebService();
            return proxy;
        }


        public void Dispose() 
        {
            this.webserviceController.DisposeWebService();
        }
    }
}
