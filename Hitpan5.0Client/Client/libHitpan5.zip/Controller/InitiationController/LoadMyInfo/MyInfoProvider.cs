﻿using libHitpan5.Controller.CommandController.Commands.CommonSetting.MyInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libHitpan5.VO;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.Controller.CommandController.CommandListener;
namespace libHitpan5.Controller.InitiationController.LoadMyInfo
{
    /// <summary>
    /// 나 자신에 대한 정보를 제공
    /// </summary>
    public class MyInfoProvider
    {
        public myInfoController myInfoCMDListener { get; set; }
        public MyInfoProvider(ICommandListener myInfoCMDListener)
        {
            this.myInfoCMDListener = (myInfoController)myInfoCMDListener;
        }
        public myInfo GetMyInfo() 
        {                        
            try
            {
                object myInfo = myInfoCMDListener.Select();
                if (myInfo != null)
                {
                    return (myInfo)myInfo;
                }
                else
                {
                    throw new Exception("알수없는 원인으로 인해 '나의 정보'를 가져오지 못했거나 아직 입력되지 않았습니다");
                }
            }
            catch (Exception)
            {               
                throw;
            }
        }
    }
}
