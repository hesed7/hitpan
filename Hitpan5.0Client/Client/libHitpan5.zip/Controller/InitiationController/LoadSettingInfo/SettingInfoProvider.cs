﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.CommonSettingController;
using libHitpan5.Controller.CommandController.Commands.CommonSetting.WorkInfo;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.InitiationController.LoadSettingInfo
{
    public class SettingInfoProvider
    {
        public WorkInfoController settingInfoCMDListener { get; set; }
        public SettingInfoProvider(ICommandListener settingInfoCMDListener)
        {
            this.settingInfoCMDListener = (WorkInfoController)settingInfoCMDListener;
        }
        public CommonSettinginfo GetCommonSetting() 
        {
            try
            {
                CommonSettinginfo settingInfo= (CommonSettinginfo)this.settingInfoCMDListener.Select();
                return settingInfo;
            }
            catch (Exception)
            {               
                throw;
            }
        }
    }
}
