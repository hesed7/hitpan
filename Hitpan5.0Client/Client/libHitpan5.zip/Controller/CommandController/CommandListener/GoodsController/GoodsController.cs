﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using libHitpan5.Model.DataModel.DataQuery;
using libHitpan5.Model.DataModel;
using libHitpan5.VO.CommonVO.GoodInfo;
using libHitpan5.VO.DBTableVO.GoodsInfo;
namespace libHitpan5.Controller.CommandController.CommandListener.GoodsController
{
    public class GoodsInfoController : AbCommandListener
    {
        internal IDataModel sqlDBManager { get; set; }
        internal SQLDataQueryRepository queryService { get; set; }
        public GoodsInfoController(IDataModel dbModel,IDataQueryRepository queryHouse)
        {
            this.sqlDBManager = (SQLDataServiceModel)dbModel;
            this.queryService = (SQLDataQueryRepository)queryHouse;
        }
        public override void Delete()
        {
            throw new NotImplementedException();
        }
        public override object Select()
        {
            throw new NotImplementedException();
        }

        public override object Select(object param)
        {
            string query = queryService.SelectGoodsAndUnitCost(((GoodInfo)param).goodInfo, true);

            IList<GoodInfo> goodInfoList = new List<GoodInfo>();
            DataTable dt= sqlDBManager.GetData(query);
            foreach (DataRow dr in dt.Rows)
            {

                GoodInfo gi = new GoodInfo();
                Goods goods = new Goods();
                GoodSeller seller = new GoodSeller();
                Parts part = new Parts();
                UnitCost ucost = new UnitCost();
                foreach (var prop in typeof(Goods).GetProperties())
                {
                    try
                    {
                        goods[prop.Name] = dr[prop.Name];
                    }
                    catch (NullReferenceException)
                    {
                        continue;
                    }
                    catch (ArgumentException) 
                    {
                        continue;
                    }
                }
                foreach (var prop in typeof(GoodSeller).GetProperties())
                {
                    try
                    {
                        long? v=Convert.ToInt64(dr[prop.Name]);
                        seller[prop.Name] = (long?)v;
                    }
                    catch (NullReferenceException)
                    {
                        continue;
                    }
                    catch (ArgumentException)
                    {
                        continue;
                    }
                }
                foreach (var prop in typeof(Parts).GetProperties())
                {
                    try
                    {
                        part[prop.Name] = Convert.ToInt64(dr[prop.Name]);
                    }
                    catch (NullReferenceException)
                    {
                        continue;
                    }
                    catch (ArgumentException)
                    {
                        continue;
                    }
                }
                foreach (var prop in typeof(UnitCost).GetProperties())
                {
                    try
                    {
                        ucost[prop.Name] = Convert.ToInt64(dr[prop.Name]);
                    }
                    catch (NullReferenceException)
                    {
                        continue;
                    }
                    catch (ArgumentException)
                    {
                        continue;
                    }
                }
                gi.goodInfo = goods;
                gi.GoodSeller = seller;
                gi.Parts = part;
                gi.UnitCost = ucost;
                goodInfoList.Add(gi);
            }
            return goodInfoList;
        }
        public override bool Insert(object data)
        {
            try
            {
                string query = queryService.InsertGoods((Goods)data);
                sqlDBManager.SetData(query);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public override bool Update(object data, object param)
        {
            try
            {
                string query = queryService.UpdateGoods((Goods)data);
                sqlDBManager.SetData(query);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public override void Delete(object param)
        {
            IList<string> queryBlock = new List<string>();
            Goods _param = (Goods)param;
            //해당되는 상품정보를 검색
            DataTable dt = sqlDBManager.GetData(queryService.SelectGoods(_param,false));
            if (dt.Rows.Count<=0 || dt==null)
            {
                return;
            }
            int GoodsPK = Convert.ToInt32(dt.Rows[0]["GoodPK"]);
            //Goods테이블에서 삭제하는 쿼리 얻어오기
            queryBlock.Add(queryService.DeleteGoods(_param, false));
            //GoodSeller 삭제하는 쿼리 얻어오기
            queryBlock.Add(queryService.DeleteSeller(_param, null,false));
            //Parts 삭제하는 쿼리 얻어오기(FinishedGoodIDX와 _param의GoodPK가 동일할때)
            queryBlock.Add(queryService.DeleteParts_With_FinalGoods(_param,false));
            queryBlock.Add(queryService.DeleteParts(_param,false));
            //UnitCost삭제하는 쿼리 얻어오기
            queryBlock.Add(queryService.DeleteUnitCost(_param,null,false));
            //상기 쿼리를 전부 리스트에 넣고 이를 하나의 트랜잭션으로 처리한다

            //쿼리블럭 가굥
            string[] strQueryList= new string[queryBlock.Count];
            for (int i = 0; i < queryBlock.Count; i++)
			{
			    strQueryList[i]=queryBlock[i];
			}
            //쿼리블럭을 하나의 트랜잭션 단위로 처리요청
            sqlDBManager.SetData(strQueryList);
        }
    }
}
