﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libHitpan5.Model.DataModel;
using Newtonsoft.Json;
using libHitpan5.VO;
using System.Data;
using libHitpan5.Model.DataModel.DataQuery;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
namespace libHitpan5.Controller.CommandController.CommandListener.SettingControllers.CommonSettingController
{
/**
 * 작업에 대한 시나리오
 * [1] 세팅값은 DB에 저장되는 것도 있지만 로컬파일에 저장되는 것도 있다 
 *  =>DB에 저장되는 값과 로컬파일에 저장되는 값을 나누어서 객체화 후에 처리
 * **/
    public class WorkInfoController : AbCommandListener
    {
        private IDataModel dbModel { get; set; }
        private IDataQueryRepository sqlQuery { get; set; }
        public WorkInfoController
            (IDataModel dbModel,
             IDataQueryRepository sqlQuery
            )
        {
            this.dbModel = dbModel;
            this.sqlQuery = sqlQuery;
        }


        public override bool Insert(object data)
        {
            /**
             * [1] data를 SettingInfo_From_DB타입과 SettingInfo_From_LocalFile타입으로 나눈다
             * [2] 위에서 나누어진 각각의 타입대로 그에 맞는 dataModel에 입력요청
             * 
             * 테스트 시나리오
             * 1.모든 값이 다 들어있는 data파라미터 입력후 상기 과정대로 진행되는지 
             * 2.SettingInfo_From_DB타입이 null인 파라미터 입력후 SettingInfo_From_LocalFile타입만 상기 과정대로 진행되는지 
             * 3. 2번의 반대로 진행
             * 4. SettingInfo_From_DB타입과 SettingInfo_From_LocalFile타입 모두 null값일때 Exception발생하는지
             * 5. 파라미터 자체가 null일때 Exception발생 하는지
             * **/
            try
            {
                if (data==null)
                {
                    throw new ArgumentNullException("입력하고자 하는 내용이 하나도 없습니다");
                }
                else
                {
                    string sqlQ = sqlQuery.insertSettingInfo((CommonSettinginfo)data);
                    dbModel.SetData(sqlQ);                    
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data">업데이트 할 내용</param>
        /// <param name="param">null이어도 상관없다</param>
        /// <returns></returns>
        public override bool Update(object data, object param)
        {
            /**
             * [1] param은 null이어도 상관없다
             * [2] data를 로컬입력용과 DB입력용으로 구분한다
             * [3] 구분한 후에는 각각의 IDataModel로 업데이트 처리 
             * 
             * 테스트시나리오
             * 1.로컬용 파라미터가 null인 경우
             * 2.DB용 파라미터가 null인 경우
             * 3.둘다 null인 경우
             * 4.아예 data가 null인 경우
             * 5.전부 입력된 경우
             * **/
            if (data==null)
            {
                return false;
            }
            CommonSettinginfo si = ((CommonSettinginfo)data);           
            string strDBQuery = sqlQuery.updateSettingInfo(si);
            dbModel.SetData(strDBQuery);                           
            return true;
        }

        public override void Delete()
        {
            /**
             * DB만 삭제하면 된다
             * **/
            string strQuery = sqlQuery.DeleteSettingInfo();
            dbModel.SetData(strQuery);
        }

        public override object Select()
        {

            //[1]DB에서 설정값 구한다
            string strSQLQuery = sqlQuery.selectSettingInfo();
            DataTable dtSQLSettingInfo= dbModel.GetData(strSQLQuery);

            //[3]DataTable안의 세팅정보 추출해서 객체화
            CommonSettinginfo si = new CommonSettinginfo();
            if (dtSQLSettingInfo != null)
            {
                string strJsonData = dtSQLSettingInfo.Rows[0][0].ToString();
                si = JsonConvert.DeserializeObject<CommonSettinginfo>(strJsonData);
            }

            //[4]
            return si;
        }

        public override object Select(object param)
        {
            throw new NotImplementedException();
        }

        public override void Delete(object param)
        {
            throw new NotImplementedException();
        }
    }
}
