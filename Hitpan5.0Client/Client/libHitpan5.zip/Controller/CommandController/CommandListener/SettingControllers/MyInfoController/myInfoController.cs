﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libHitpan5.VO;
using libHitpan5.Model.DataModel;
using System.Data;
using libHitpan5.Model.DataModel.DataQuery;
using Newtonsoft.Json;
namespace libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController
{
    public class myInfoController : AbCommandListener
    {
        private IDataModel dataModel { get; set; }
        private IDataQueryRepository query { get; set; }
        public myInfoController(IDataModel dataModel, IDataQueryRepository sqlQuery)
        {
            this.dataModel = dataModel;
            this.query = sqlQuery;
        }
        /// <summary>
        /// TDD용
        /// </summary>
        public myInfoController()
        {

        }

        /// <summary>
        /// 나 자신의 정보를 반환
        /// </summary>
        /// <returns>
        /// myInfo타입으로 변형할수 있는 object
        /// </returns>
        public override object Select() 
        {
            string jsonData=dataModel.GetData(query.GetMyInfo()).Rows[0][0].ToString();
            myInfo _myInfo= (myInfo)JsonConvert.DeserializeObject(jsonData,typeof(myInfo));
            return _myInfo;
        }

        public override object Select(object param)
        {
            throw new NotImplementedException();
        }

        public override void Delete() 
        {
            dataModel.SetData(query.DeleteMyInfo());
        }


  
        public override bool Insert(object data)
        {
            myInfo MyInfo = (myInfo)data;
            try
            {
                dataModel.SetData(query.InsertMyInfo(MyInfo));                
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public override bool Update(object data, object param)
        {
            try
            {
                myInfo MyInfo = (myInfo)data;
                dataModel.SetData(query.UpdateMyInfo(MyInfo));
                return true;
            }
            catch (Exception)
            {
                
                throw;
            }             
        }

        public override void Delete(object param)
        {
            throw new NotImplementedException();
        }
    }
}
