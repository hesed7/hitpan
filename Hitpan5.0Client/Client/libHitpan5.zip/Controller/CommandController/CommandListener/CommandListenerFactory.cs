﻿using libHitpan5.enums;
using libHitpan5.Model.DataModel;
using libHitpan5.Model.DataModel.DataQuery;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.CommandListener
{
    internal class CommandListenerFactory
    {
        internal IDataModel sqlModel { get; set; }
        internal IDataQueryRepository sqlQueryHouse { get; set; }
        public CommandListenerFactory(IDataModel sqlModel,IDataQueryRepository sqlQueryHouse)
        {
            this.sqlModel = sqlModel;
            this.sqlQueryHouse = sqlQueryHouse;
        }
        internal ICommandListener GetCommandListener(CommandListenerType cmdListenerType) 
        {
            ICommandListener listener = null;
            switch (cmdListenerType)
            {
                case CommandListenerType.userAuth:
                    listener = new UserAuthController.UserAuthController(this.sqlModel,this.sqlQueryHouse);
                    break;
                case CommandListenerType.myInfo:
                    listener = new SettingControllers.MyInfoController.myInfoController(sqlModel,sqlQueryHouse);
                    break;
                case CommandListenerType.workInfo:
                    listener = new SettingControllers.CommonSettingController.WorkInfoController(sqlModel,sqlQueryHouse);
                    break;
                case CommandListenerType.goods:
                    listener = new GoodsController.GoodsInfoController(sqlModel,sqlQueryHouse);
                    break;
                default:
                    break;
            }//End  of Switch
            return listener;
        }
    }
}
