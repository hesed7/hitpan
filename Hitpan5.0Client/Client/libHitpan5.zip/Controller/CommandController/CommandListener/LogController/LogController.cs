﻿using libHitpan5.enums;
using libHitpan5.Model.DataModel;
using libHitpan5.Model.DataModel.DataQuery;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.IO;
namespace libHitpan5.Controller.CommandController.CommandListener
{
    public class LogController
    {
        #region 싱글턴
        internal IDataModel DB { get; set; }
        internal IDataQueryRepository SQLQueryHouse { get; set; }
        internal LogController(IDataModel DB, IDataQueryRepository SQLQueryHouse)
        {
            this.DB = DB;
            this.SQLQueryHouse = SQLQueryHouse;
        }
        /// <summary>
        /// TDD
        /// </summary>
        public LogController()
        {

        }
        #endregion

        public void WriteLog(LogType type,string user,string content) 
        {
            //임시로그파일 경로
            string tempLogPath=string.Format("{0}\\templog.sql",Environment.CurrentDirectory);
            #region 쿼리작성
            if (user == null || user == string.Empty)
            {
                user = string.Format("{0}\\{1}", "System", Environment.UserDomainName);
            }
            string timeLine = string.Empty;
            try
            {
                timeLine = ((SQLDataServiceModel)DB).sqlProxy.GetTime().ToString();
            }
            catch (Exception)
            {
                //연결에 이싱이 생겨서 서비스에서 시간정보를 가져올수 었는 경우
                timeLine = DateTime.Now.ToString();
            }
            string query = SQLQueryHouse.InsertLog(type, user, content, timeLine); 
            #endregion
            #region 임시파일에 쿼리 입력
            //우선 임시로그파일에 로그쿼리 입력
            File.AppendAllText(tempLogPath, query + "\r\n", Encoding.UTF8); 
            #endregion
            #region 임시파일에 있는 쿼리를 전부 DB에 입력, 임시파일 삭제,입력 실패한 쿼리는 따로 모아놓는다
            string[] arrQuery = File.ReadAllLines(tempLogPath, Encoding.UTF8);
            IList<string> FaultedQuerys = new List<string>();
            File.Delete(tempLogPath);
            foreach (string _query in arrQuery)
            {
                try
                {
                    DB.SetData(_query);
                }
                catch (Exception)
                {
                    //성공하지 못한 쿼리는 다시 모아놓는다
                    FaultedQuerys.Add(_query);
                }
            }//End of Foreach 
            #endregion
            #region 입력 실패한 쿼리로 다시 임시파일 작성
            foreach (string q in FaultedQuerys)
            {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(q);
                sbQuery.Append("\r\n");
                File.AppendAllText(tempLogPath, sbQuery.ToString(), Encoding.UTF8);
            } 
            #endregion
        }

        public DataTable GetLog(DateTime firstdt, DateTime lastdt, Log logVO) 
        {
            string query = SQLQueryHouse.GetLog(firstdt, lastdt, logVO);
            DataTable data= DB.GetData(query);
            return data;
        }
    }
}
