﻿using libHitpan5.Model.DataModel;
using System;
namespace libHitpan5.Controller.CommandController.CommandListener
{
    public interface ICommandListener
    {
        bool Insert(object data);
        bool Update(object data, object param);
        object Select();
        object Select(object param);
        void Delete();
        void Delete(object param);
    }
}
