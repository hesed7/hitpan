﻿using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.enums;
using libHitpan5.Model.DataModel;
using libHitpan5.Model.DataModel.DataQuery;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.CommandListener.UserAuthController
{
    public class UserAuthController : AbCommandListener
    {
        internal IDataModel sqlDBManager { get; set; }
        internal IDataQueryRepository query { get; set; }
        public UserAuthController(IDataModel sqlDBManager, IDataQueryRepository query)
        {
            this.sqlDBManager = sqlDBManager;
            this.query = query;
        }
        /// <summary>
        /// TDD용
        /// </summary>
        public UserAuthController()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data">UserInfo 객체</param>
        /// <returns></returns>
        public override bool Insert(object data)
        {
            try
            {
                UserInfo user_info = (UserInfo)data;
                if (user_info.id==null || user_info.password==null ||user_info.userAuth==null)
                {
                    throw new ArgumentNullException("아이디나 패스워드 또는 사용자권한이 입력되지 않았습니다");
                }
                string query = this.query.InsertUserAuth(user_info.id, user_info.password, user_info.userAuth, user_info.userType);
                sqlDBManager.SetData(query);
                return true;
            }
            catch (ArgumentNullException) 
            {
                throw;
            }
            catch (Exception)
            {

                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data">
        /// UserInfo타입 객체(수정할 내용)
        /// </param>
        /// <param name="param">
        /// UserInfo타입 객체(수정될 내용)
        /// </param>
        /// <returns></returns>
        public override bool Update(object data, object param)
        {
            try
            {
                UserInfo content = (UserInfo)data;
                UserInfo _param = (UserInfo)param;
                if (content.id==null || content.password==null || content.userAuth==null ||_param.id ==null)
                {
                    throw new ArgumentNullException("업데이트할 내용중 하나가 입력되지 않았거나 기준이 되는 id,password가 입력되지 않았습니다");
                }
                string query = this.query.UpdateUserAuth(content.id, content.password, _param.id, content.userAuth, content.userType);
                sqlDBManager.SetData(query);
                return true;
            }
            catch (ArgumentNullException) 
            {
                throw;
            }
            catch (Exception)
            {

                return false;
            }
        }
        /// <summary>
        /// 모든 아이디 반환
        /// </summary>
        /// <returns></returns>
        public override object Select()
        {
            string query = this.query.SelectUserAuth();
            DataTable dt= sqlDBManager.GetData(query);
            return dt;
        }
        /// <summary>
        /// 모든 아이디 반환
        /// </summary>
        /// <returns></returns>
        public  DataTable Select(string id)
        {
            string query = this.query.SelectUserAuth(id);
            DataTable dt = sqlDBManager.GetData(query);
            return dt;
        }
        /// <summary>
        /// 로그인과정
        /// 
        /// </summary>
        /// <param name="param">
        /// UserInfo 타입 객체
        /// </param>
        /// <returns></returns>
        public override object Select(object param)
        {
            try
            {
                UserInfo _param = (UserInfo)param;
                string query = this.query.SelectUserAuth(_param.id);
                if (_param.id == null || _param.id.Replace(" ", string.Empty) == string.Empty ||
                    _param.password == null || _param.password.Replace(" ", string.Empty) == string.Empty
                   )
                {
                    throw new ArgumentNullException("아이디나 패스워드가 없습니다");
                }
                DataTable dt = sqlDBManager.GetData(query);
                string password = dt.Rows[0]["userPassword"].ToString();
                if (password == _param.password)
                {
                    DataRow dr = dt.Rows[0];
                    UserInfo uInfo = new UserInfo();
                    uInfo.id = dr["userID"].ToString();
                    uInfo.password = dr["userPassword"].ToString();
                    uInfo.userAuth = "";
                    uInfo.userType = 사용자등급.일반사용자;
                    try
                    {
                        uInfo.userAuth = dr["userAuth"].ToString();
                        uInfo.userType = (사용자등급)Convert.ToInt32(dr["userType"]);
                    }
                    catch (InvalidCastException) { }
                    return uInfo;
                }
                else
                {
                    throw new PasswordMissMatchException("패스워드가 일치하지 않습니다");
                }
            }
            catch (ArgumentNullException)
            {
                throw new ArgumentNullException("아이디나 패스워드가 입력되지 않았습니다");
            }
            catch (IndexOutOfRangeException)
            {
                throw new IndexOutOfRangeException("해당되는 아이디가 없습니다");
            }
            catch (Exception) 
            {
                throw;
            }
        }


        public override void Delete()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 유저계정 제한
        /// </summary>
        /// <param name="param">
        /// id값(String 타입)
        /// </param>
        public override void Delete(object param)
        {
            try
            {
                string query = this.query.DeleteUserInfo(param.ToString());
                this.sqlDBManager.SetData(query);
            }
            catch (NullReferenceException)
            {              
                throw new ArgumentNullException("아이디가 입력되지 않았습니다");
            }            
        }
    }

    public class PasswordMissMatchException : Exception
    {
        public PasswordMissMatchException(string message)
            :base(message)
        {

        }
        public PasswordMissMatchException()
        {

        }
    }
}
