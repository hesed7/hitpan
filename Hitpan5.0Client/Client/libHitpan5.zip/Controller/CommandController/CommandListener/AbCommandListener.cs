﻿using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.CommandListener
{
    public abstract class AbCommandListener : ICommandListener
    {
        protected enum 작업내용 { Delete, Insert,Update }
        protected 작업내용 Work { get; set; }
        
        abstract public void Delete();
        abstract public object Select();
        abstract public object Select(object param);
        //abstract public bool UnDO();
        abstract public bool Insert(object data);
        abstract public bool Update(object data, object param);
        abstract public void Delete(object param);
    }
}
