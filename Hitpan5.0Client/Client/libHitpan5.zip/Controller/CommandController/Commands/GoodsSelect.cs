﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands
{
    class GoodsSelect :AbCommand
    {
        public override bool execute()
        {
            throw new NotImplementedException();
        }

        public override bool execute(out object returnValue)
        {
            throw new NotImplementedException();
        }

        public override bool Undo()
        {
            throw new NotImplementedException();
        }
    }
}
