﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.enums;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands.CommonSetting.WorkInfo
{
    public class WorkInfoInsertUpdateCommand :AbCommand
    {
        internal object settingInfo { get; set; }
        public WorkInfoInsertUpdateCommand(ICommandListener cmdListener,CommonSettinginfo settingInfo)
        {
            base.CMDListener = cmdListener;
            base.description = "세팅정보 입력/수정";
            base.logType = LogType.히트판세팅;
            base.param = settingInfo;            
            this.settingInfo = base.CMDListener.Select();
        }
        public override bool execute()
        {           
            try
            {
                if (this.settingInfo != null)
                {
                    CMDListener.Update(this.param, null);
                }
                else
                {
                    CMDListener.Insert(this.param);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public override bool execute(out object returnValue)
        {
            throw new NotImplementedException();
        }

        public override bool Undo()
        {
            try
            {
                base.CMDListener.Delete();
                if (this.settingInfo!=null)
                {
                    base.CMDListener.Insert(this.settingInfo);
                }                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
