﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.enums;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands.CommonSetting.WorkInfo
{
    public class WorkInfoSelectCommand :AbCommand
    {
        public WorkInfoSelectCommand(ICommandListener cmdListener)
        {
            base.CMDListener = cmdListener;
            base.description = "세팅정보 조회";
            base.logType = LogType.히트판세팅;
        }
        public override bool execute()
        {
            throw new NotImplementedException();
        }

        public override bool execute(out object returnValue)
        {
            returnValue = new CommonSettinginfo();
            try
            {               
                returnValue = base.CMDListener.Select();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public override bool Undo()
        {
            return true;
        }
    }
}
