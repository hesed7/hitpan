﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libHitpan5.VO;
using libHitpan5.enums;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.Controller.CommandController.CommandListener;
namespace libHitpan5.Controller.CommandController.Commands.CommonSetting.MyInfo
{
    public class MyInfoInsertUpdateCommand :AbCommand
    {
        public object preMyInfo { get; set; }
        public MyInfoInsertUpdateCommand(myInfo myInfo,ICommandListener MyInfoWorker)
        {
            base.param = myInfo;
            base.description = "자신의 정보 입력,수정 ";
            base.logType = LogType.히트판세팅;
            base.CMDListener = MyInfoWorker;
            UserAuth ua = new UserAuth();
            ua.나의정보관리 = 사용자권한.조회만가능;
            base.userAuth = ua;
        }
        public override bool execute()
        {
            bool isSucc = false;
            try
            {
                //파라미터가 null로 주어진 경우를 처리
                if (base.param==null)
                {
                    throw new ArgumentNullException("입력할 정보가 없습니다");
                }
                try
                {
                    //내 정보가 입력된게 있는지 검색해 본다
                    preMyInfo = CMDListener.Select();
                    if (preMyInfo == null)
                    {
                        throw new NullReferenceException();
                    }
                    //기존에 입력된 정보가 있는 경우
                    isSucc = base.CMDListener.Update(base.param, null);
                }
                catch (Exception)
                {
                    // 기존에 입력된 정보가 하나도 없는 경우
                    isSucc = CMDListener.Insert((myInfo)base.param);
                }               
            }
            catch (Exception)
            {                
                throw;
            }
            return isSucc;
        }

        public override bool Undo()
        {
            try
            {
                //삭제
                CMDListener.Delete(base.param);
                //만약 작업전에 입력되엇던 내용이 있으면 그 내용 입력
                if (preMyInfo!=null)
                {
                   return base.CMDListener.Insert(preMyInfo);
                }
                else
                {
                    return true;
                }
                
            }
            catch (Exception)
            {
                throw;
            }
        }

        public override bool execute(out object returnValue)
        {
            throw new NotImplementedException();
        }
    }//End of MyInfoInsertUpdateCommand
}
