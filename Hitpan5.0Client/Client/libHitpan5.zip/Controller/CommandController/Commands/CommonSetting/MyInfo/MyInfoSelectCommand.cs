﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.enums;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands.CommonSetting.MyInfo
{
    public class MyInfoSelectCommand : AbCommand
    {
        public MyInfoSelectCommand(ICommandListener myInfoListener)
        {
            base.description = "자신의 정보 조회 ";
            base.logType = LogType.히트판세팅;
            base.CMDListener = myInfoListener;
            UserAuth ua = new UserAuth();
            ua.나의정보관리 = 사용자권한.조회만가능;
            base.userAuth = ua;       
        }
        public override bool execute()
        {
            throw new NotImplementedException();
        }

        public override bool Undo()
        {
            return true;
        }

        public override bool execute(out object returnValue)
        {
            bool isSucc = false;
            returnValue = null;
            try
            {
                returnValue = CMDListener.Select();
                isSucc = true;
            }
            catch (Exception)
            {
                throw;
            }
            return isSucc;
        }
    }//End of MyInfoSelectCommand
}
