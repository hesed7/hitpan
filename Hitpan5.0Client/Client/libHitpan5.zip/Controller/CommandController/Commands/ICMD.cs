﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libHitpan5.enums;
using libHitpan5.VO;
namespace libHitpan5.Controller.CommandController
{
    public interface ICMD
    {
        UserAuth userAuth { get; set; }
        LogType logType { get; set; }
        string description { get; set; }
        object param { get; set; }
        bool execute();
        bool execute(out object returnValue);
        bool Undo();
    }
}
