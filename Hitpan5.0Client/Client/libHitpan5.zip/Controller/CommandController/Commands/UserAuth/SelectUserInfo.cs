﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.Controller.CommandController.CommandListener.UserAuthController;
using libHitpan5.enums;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands._UserAuth
{
    public class SelectUserInfo :AbCommand
    {
        public SelectUserInfo(ICommandListener CMDListener)
        {
            base.CMDListener = CMDListener;
            base.description = "모든 사용자 정보 조회";
            base.logType = enums.LogType.유저정보;
            base.param=null;

            UserAuth user_auth=new UserAuth();
            user_auth.계정관리=사용자권한.조회만가능;
            base.userAuth = user_auth;
        }

        public SelectUserInfo(ICommandListener CMDListener,string id)
        {
            base.CMDListener = CMDListener;
            base.description = string.Format("{0} 사용자의 정보 조회",id);
            base.logType = enums.LogType.유저정보;
            base.param = id;

            UserAuth user_auth = new UserAuth();
            user_auth.계정관리 = 사용자권한.조회만가능;
            base.userAuth = user_auth;
        }
        public override bool execute()
        {
            throw new NotImplementedException();
        }

        public override bool execute(out object returnValue)
        {
            returnValue = null;
            bool isOK = false;
            try
            {
                //[1] id 파라미터가 있는가 없는가 구분해서 값 구함
                DataTable dt = null;
                if (base.param != null && base.param.ToString().Replace(" ",string.Empty)!=string.Empty)
                {
                    dt = ((UserAuthController)CMDListener).Select(base.param.ToString());
                }
                else
                {
                    dt = (DataTable)CMDListener.Select();
                }
                //[2] 구한 값을 out파라미터로 내보낸다
                returnValue = dt;
                isOK = true;
            }
            catch (Exception) { }
            return isOK;
        }

        public override bool Undo()
        {
            return true;
        }
    }
}
