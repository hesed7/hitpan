﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.Controller.CommandController.CommandListener.UserAuthController;
using libHitpan5.enums;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands._UserAuth
{
    public class UpdateUserInfo :AbCommand
    {
        public object preUserInfo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data">
        /// 수정하고자 하는 내용이 들어간 VO
        /// ID는 수정불가.. 그러므로 여기에 들어간 ID는 수정할 계정의ID
        /// </param>
        /// <param name="userWorker"></param>
        public UpdateUserInfo(UserInfo data,ICommandListener userWorker)
        {
            if (data==null)
            {
                throw new ArgumentNullException("수정하고자 하는 정보가 없습니다");
            }
            base.CMDListener = userWorker;
            base.description = string.Format("{0} 계정정보를 수정",data.id);
            base.logType = LogType.유저정보;
            base.param = data;
            UserAuth ua = new UserAuth();
            ua.계정관리 = 사용자권한.모두허용;
            base.userAuth = ua;                   
        }
        public override bool execute()
        {
            //업데이트 할 계정정보 객체 알아내기

            //해당되는 계정의 지금정보 저장
            preUserInfo = ((UserAuthController)base.CMDListener).Select(((UserInfo)base.param).id);
            //[Final] CMDListener에게 업데이트 요청
            bool isOK = base.CMDListener.Update(base.param, base.param);
            return isOK;
        }

        public override bool Undo()
        {
            // preUserInfo가 없는 경우 체크
            if (preUserInfo==null)
            {
                throw new ArgumentNullException(string.Format("{0} 계정에 대한 수정작업 이전의 데이터가 없습니다",((UserInfo)base.param).id));
            }
            // preUserInfo로 업데이트
            bool isRemoved = base.CMDListener.Update(preUserInfo,preUserInfo);
            return isRemoved;
        }

        public override bool execute(out object returnValue)
        {
            throw new NotImplementedException();
        }
    }
}
