﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using libHitpan5.Controller.CommandController.CommandListener.UserAuthController;
using libHitpan5.enums;
using libHitpan5.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libHitpan5.Controller.CommandController.Commands._UserAuth
{
    public class MakeAuth : AbCommand
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="param">
        /// 입력할 유저정보
        /// </param>
        public MakeAuth(UserInfo param,ICommandListener CMDListener)
        {
            base.CMDListener = CMDListener;
            base.logType = LogType.유저정보;
            try
            {
                if (param==null)
                {
                    throw new ArgumentNullException();
                }
                base.param = param;
                base.description = string.Format("{0} 계정 생성", param.id);  
   
                UserAuth ua= new UserAuth();
                ua.계정관리=사용자권한.모두허용;
                base.userAuth = ua;       
            }
            catch (NullReferenceException)
            {               
                throw new ArgumentNullException("아이디,패스워드,권한설정 파라미터중 하나가 null이거나 빈값입니다");
            }           
        }

        /// <summary>
        /// 아이디 리스트(아이디 중복 체크용)
        /// TDD때문에 밖으로 뺐음
        /// </summary>
        public string[] strIDList = null;
        /// <summary>
        /// 계정생성
        /// </summary>
        /// <returns></returns>
        public override bool execute()
        {
            //[1] 파라미터 중에 Null이나 빈값이 있는 경우 처리
            UserInfo param = ((UserInfo)base.param);
            if (param==null ||
                param.id == null ||
                param.id.Replace(" ", string.Empty) == string.Empty ||
                param.password == null ||
                param.password.Replace(" ", string.Empty) == string.Empty ||
                param.userAuth == null || param.userAuth.Replace(" ", string.Empty) == string.Empty)
            {
                throw new ArgumentNullException("입력하고자 하는 내용중에 빈값이나 Null이 있습니다");
            }
            //[2] 기존에 같은 내용으로 입력된 아이디가 있는지 검증
            object obj= base.CMDListener.Select();
            try
            {
                strIDList = (string[])obj;
            }
            catch (InvalidCastException) { }
            if (strIDList!=null && strIDList.Contains<string>(((UserInfo)base.param).id))
            {
                throw new AlreadyExsistedIDException("입력하고자 하는 아이디가 이미 존재합니다");
            }
            //[3] 사용자등급이 페기인 경우
            if (((UserInfo)base.param).userType==사용자등급.페기)
            {
                UserInfo new_Param = new UserInfo();
                new_Param.id = ((UserInfo)base.param).id;
                new_Param.password = ((UserInfo)base.param).password;
                new_Param.userAuth = ((UserInfo)base.param).userAuth;
                new_Param.userType = 사용자등급.일반사용자;
                base.param = new_Param;
            }

            //[Final] 입력
            bool isOK= base.CMDListener.Insert(base.param);
            return isOK;
        }

        /// <summary>
        /// 계정삭제
        /// </summary>
        /// <returns></returns>
        public override bool Undo()
        {
            //[1]파라미터가 있는지 검증           
            string id = ((UserInfo)base.param).id;
            if (id==null || id.Replace(" ",string.Empty)==string.Empty)
            {
                throw new ArgumentNullException("입력을 취소할 계정의 정보가 없습니다");
            }
            //[Final] 사용자등급을 페기로
            base.CMDListener.Delete(base.param);
            return true;
        }

        public override bool execute(out object returnValue)
        {
            throw new NotImplementedException();
        }
    }
    public class AlreadyExsistedIDException : Exception
    {
        public AlreadyExsistedIDException(string message):base(message)
        {

        }
        public AlreadyExsistedIDException()
        {

        }
        
    }
}
