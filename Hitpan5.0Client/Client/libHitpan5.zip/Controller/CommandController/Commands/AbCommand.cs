﻿using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace libHitpan5.Controller.CommandController.Commands
{
    public abstract class AbCommand :ICMD
    {
        public VO.UserAuth userAuth { get; set; }
        public enums.LogType logType { get; set; }
        public string description { get; set; }
        public object param { get; set; }
        public ICommandListener CMDListener { get; set; }

        abstract public bool execute();
        abstract public bool execute(out object returnValue);
        abstract public bool Undo();

        

    }
}
