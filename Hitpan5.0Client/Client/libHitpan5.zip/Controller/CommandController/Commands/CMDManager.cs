﻿using System;
using System.Collections.Generic;
using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.VO;
using libHitpan5.enums;
using Newtonsoft.Json;
namespace libHitpan5.Controller.CommandController
{
    public class CMDManager
    {
        #region 공통필수정보
        internal UserInfo userInfo { get; set; }
        internal myInfo myInfo { get; set; }
        internal CommonSettinginfo SettingInfo { get; set; }        
        #endregion
        #region 싱글턴
        private LogController Logger { get; set; }
        private Stack<ICMD> stackCommand { get; set; }
        private Stack<ICMD> stackCanceledCommnad { get; set; }
        private static CMDManager instance { get; set; }
        internal CMDManager(LogController loger, CommonSettinginfo settingInfo, UserInfo userinfo, myInfo myInfo)
        {
            stackCommand = new Stack<ICMD>(10);
            stackCanceledCommnad = new Stack<ICMD>(10);
            Logger = loger;

            this.SettingInfo = settingInfo;
            this.userInfo = userinfo;
            this.myInfo = myInfo;
        }


        #endregion
        #region DO(처음 작업할 때)
        public void Do(ICMD cmd)
        {
            //로그인 안한 상태면 예외발생시킨다
            if (this.userInfo == null)
            {
                throw new NotLoginException();
            }
            //권한없는 ID이면 예외발생시킨다
            if (!CheckUserAuth(cmd))
            {
                throw new NotAuthException();
            }

            DoWork(cmd);
        }
        public void Do(ICMD cmd, ref object returnValue)
        {
            //로그인 안한 상태면  예외발생시킨다
            if (this.userInfo == null)
            {
                throw new NotLoginException();
            }
            //권한없는 ID이면 예외발생시킨다
            if (!CheckUserAuth(cmd))
            {
                throw new NotAuthException();
            }
            DoWork(cmd,ref returnValue);
        }
        private void DoWork(ICMD cmd,ref object returnValue)
        {
            UserInfo userInfo = (UserInfo)this.userInfo;
            string log = string.Format("{0} 시도", cmd.description);
            try
            {
                Logger.WriteLog(cmd.logType, userInfo.id, log);
                bool isSucc = cmd.execute(out returnValue);
                if (isSucc)
                {
                    stackCommand.Push(cmd);
                    log = string.Format("{0} 성공", cmd.description);
                    Logger.WriteLog(cmd.logType, userInfo.id, log);
                }
                else
                {
                    log = string.Format("{0} 실패", cmd.description);
                    Logger.WriteLog(cmd.logType, userInfo.id, log);
                }
            }
            catch (Exception ex)
            {
                log = string.Format("{0} 도중 예외발생 : {1}", cmd.description, ex.Message);
                Logger.WriteLog(LogType.에러, userInfo.id, log);
            }
        }
        private void DoWork(ICMD cmd)
        {
            UserInfo userInfo = (UserInfo)this.userInfo;
            string log = string.Format("{0} 시도", cmd.description);
            try
            {
                Logger.WriteLog(cmd.logType, userInfo.id, log);
                bool isSucc = cmd.execute();
                if (isSucc)
                {
                    stackCommand.Push(cmd);
                    log = string.Format("{0} 성공", cmd.description);
                    Logger.WriteLog(cmd.logType, userInfo.id, log);
                }
                else
                {
                    log = string.Format("{0} 실패", cmd.description);
                    Logger.WriteLog(cmd.logType, userInfo.id, log);
                }
            }
            catch (Exception ex)
            {
                log = string.Format("{0} 도중 예외발생 : {1}", cmd.description, ex.Message);
                Logger.WriteLog(LogType.에러, userInfo.id, log);
            }
        } 
        #endregion
        /// <summary>
        /// 작업취소
        /// </summary>
        public void UnDo() 
        {
            UserInfo userInfo = (UserInfo)this.userInfo;
            ICMD cmd = stackCommand.Pop();
            try
            {
                bool isSucc = cmd.Undo();
                if (isSucc)
                {
                    stackCanceledCommnad.Push(cmd);
                    string log = string.Format("{0}  취소", cmd.description);
                    Logger.WriteLog(cmd.logType, userInfo.id, log);
                }
                else
                {
                    stackCommand.Push(cmd);
                }
            }
            catch (Exception ex)
            {               
                stackCommand.Push(cmd);
                string log = string.Format("{0} 도중 예외발생 : {1}", cmd.description, ex.Message);
                Logger.WriteLog(LogType.에러, userInfo.id, log);
            }
            
        }//End of UnDo()
        /// <summary>
        /// 취소한 작업 다시 실행
        /// </summary>
        public void ReDo() 
        {
            UserInfo userInfo = (UserInfo)this.userInfo;
            ICMD cmd = stackCanceledCommnad.Pop();
            try
            {
                bool isSucc = cmd.execute();
                if (isSucc)
                {
                    stackCommand.Push(cmd);
                    string log = string.Format("{0}  다시 시도", cmd.description);
                    Logger.WriteLog(cmd.logType, userInfo.id, log);
                }
                else
                {
                    stackCanceledCommnad.Push(cmd);
                }
            }
            catch (Exception ex)
            {               
                stackCanceledCommnad.Push(cmd);
                string log = string.Format("{0} 도중 예외발생 : {1}", cmd.description, ex.Message);
                Logger.WriteLog(LogType.에러, userInfo.id, log);
            }
        }//End of ReDo()
        #region 사용자권한 체크
        /// <summary>
        /// 사용자권한 체크
        /// </summary>
        /// <returns>
        /// 허용되면 true(CMD의 UserAuth가 설정이 안된 경우에는 무조건 모든 계정에 대해 허용된 것으로 본다)
        /// 허용되지 않으면 false;
        /// </returns>
        private bool CheckUserAuth(ICMD cmd)
        {
            bool isOK = false;
            UserAuth RequeredAuth = cmd.userAuth;
            if (RequeredAuth==null)
            {
                return true; 
            }
            foreach (var auth in typeof(UserAuth).GetProperties())
            {

                if (RequeredAuth[auth.Name] != 사용자권한.관리불가)
                {
                    try
                    {
                        UserAuth user_Auth = (UserAuth)JsonConvert.DeserializeObject(((UserInfo)this.userInfo).userAuth, typeof(UserAuth));
                        if (Convert.ToInt32(RequeredAuth[auth.Name]) <= Convert.ToInt32(user_Auth[auth.Name]))
                        {
                            isOK = true;
                            break;
                        }
                    }
                    catch (Exception)
                    {
                        isOK = false; ;
                        break;
                    }
                }
            }//End of Foreach
            return isOK;
        }//End of CheckUserAuth() 
        #endregion
    }//End of CMDManager
    #region 로그인 예외
    /// <summary>
    /// 로그인을 하지 않은 경우의 예외
    /// </summary>
    public class NotLoginException : Exception
    {
        public NotLoginException()
            : base("로그인을 하지 않았습니다")
        {

        }
    }
    /// <summary>
    /// 실행권한 없는 계정인 경우의 예외
    /// </summary>
    public class NotAuthException : Exception
    {
        public NotAuthException()
            : base("권한이 없습니다")
        {

        }
    } 
    #endregion
}
