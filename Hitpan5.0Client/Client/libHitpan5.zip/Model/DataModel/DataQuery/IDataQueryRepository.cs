﻿using libHitpan5.enums;
using System;
namespace libHitpan5.Model.DataModel.DataQuery
{
    public interface IDataQueryRepository
    {        
        string GetLog(DateTime firstdt, DateTime lastdt, libHitpan5.VO.Log log);
        string InsertLog(libHitpan5.enums.LogType type, string user, string log,string timeLine);

        string GetMyInfo();
        string DeleteMyInfo();        
        string InsertMyInfo(libHitpan5.VO.myInfo myInfo);
        string UpdateMyInfo(libHitpan5.VO.myInfo myInfo);

        string insertSettingInfo(libHitpan5.VO.CommonSettinginfo param);
        string updateSettingInfo(libHitpan5.VO.CommonSettinginfo param);
        string DeleteSettingInfo();
        string selectSettingInfo();

        string InsertUserAuth(string id, string password, string Auth,사용자등급 userType);
        string UpdateUserAuth(string id, string password, string preID, string Auth,사용자등급 userType);
        string SelectUserAuth(string id);
        string SelectUserAuth();
        /// <summary>
        /// 사용자권한 전부 박탈
        /// 심지어 로그인도 못하게 함
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string DeleteUserInfo(string id);            
    }
}
