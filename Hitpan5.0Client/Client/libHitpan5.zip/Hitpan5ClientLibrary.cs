﻿using libHitpan5.Controller.CommandController;
using libHitpan5.Controller.InitiationController.WebServiceProxy;
using libHitpan5.Controller.WebServiceController;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libHitpan5.Model.DataModel;
using libHitpan5.Model.DataModel.DataQuery;
using libHitpan5.Controller.CommandController.CommandListener;
using libHitpan5.enums;
using libHitpan5.VO.CommonVO;
using libHitpan5.VO;
using libHitpan5.Controller.InitiationController.LoadSettingInfo;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.CommonSettingController;
using libHitpan5.Controller.InitiationController.LoadMyInfo;
using libHitpan5.Controller.CommandController.CommandListener.SettingControllers.MyInfoController;
using System.ServiceModel;
namespace libHitpan5
{
    public class Hitpan5ClientLibrary
    {
        #region 웹서비스 접속 등 내부 로직에 필요한 객체
        private string ServiceURL { get; set; }
        private string EncryptSeed { get; set; }
        private IDataModel SQLDataServiceModel { get; set; }
        private IDataQueryRepository SQLQueryHouse { get; set; }
        private CommandListenerFactory CMDListenerFactory { get; set; }
        private LogController logger { get; set; }
        private WebServiceProxyProvider proxyProvider { get; set; }
        #endregion
        #region 웹서비스 접속인증,프록시객체
        /// <summary>
        /// 웹서비스 인증방식
        /// </summary>
        public MessageCredentialType MessageCredentialType { get; set; }
        /// <summary>
        /// 웹서비스 프록시
        /// </summary>
        public ISQLWebService proxy { get; set; } 
        #endregion               
        #region 사용 기본 정보
        public CommonSettinginfo settingInfo { get; set; }
        public UserInfo userInfo { get; set; }
        public myInfo myInfo { get; set; } 
        #endregion
        /// <summary>
        /// 입력,수정,삭제 작업할 커맨드매니져객체(로깅,되돌리기등을 일괄적으로 처리)
        /// </summary>
        public CMDManager CommandManager { get; set; }

        /// <summary>
        /// 사용자 id인증으로 메시지보안 적용
        /// </summary>
        /// <param name="ServiceURL"></param>
        /// <param name="EncryptSeed"></param>
        /// <param name="id"></param>
        /// <param name="password"></param>
        public Hitpan5ClientLibrary(string ServiceURL,string EncryptSeed,string id,string password)
        {
            this.ServiceURL = ServiceURL;
            this.EncryptSeed = EncryptSeed;
            WebServiceProxyProvider proxyProvider = new WebServiceProxyProvider(new WebServiceProxyController(id,password,ServiceURL));
                       
            this.proxy = proxyProvider.GetWebServiceProxy();
            this.proxyProvider = proxyProvider;
            this.SQLDataServiceModel = new SQLDataServiceModel(this.EncryptSeed, this.ServiceURL, this.proxy);
            this.SQLQueryHouse = new SQLDataQueryRepository();

            this.logger = new LogController(this.SQLDataServiceModel, this.SQLQueryHouse);

            this.CMDListenerFactory = new CommandListenerFactory(this.SQLDataServiceModel, this.SQLQueryHouse);
        }

        /// <summary>
        /// 아무런 보안도 적용 안함
        /// </summary>
        /// <param name="ServiceURL"></param>
        /// <param name="EncryptSeed"></param>
        public Hitpan5ClientLibrary(string ServiceURL, string EncryptSeed)
        {
            this.ServiceURL = ServiceURL;
            this.EncryptSeed = EncryptSeed;
            WebServiceProxyProvider proxyProvider = new WebServiceProxyProvider(new WebServiceProxyController(ServiceURL));

            this.proxy = proxyProvider.GetWebServiceProxy();
            this.proxyProvider = proxyProvider;
            this.SQLDataServiceModel = new SQLDataServiceModel(this.EncryptSeed, this.ServiceURL, this.proxy);
            this.SQLQueryHouse = new SQLDataQueryRepository();

            this.logger = new LogController(this.SQLDataServiceModel, this.SQLQueryHouse);

            this.CMDListenerFactory = new CommandListenerFactory(this.SQLDataServiceModel, this.SQLQueryHouse);
        }
 
        /// <summary>
        /// 로그인을 담당
        /// 로그인이 되면 커맨드매니져객체에 해당 유저정보를 넘기고
        /// 로그인이 실패하면 웹서비스프록시를 Dispose시키고 해당 실패 이유를 예외로서 Throw한다
        /// </summary>
        /// <param name="id"></param>
        /// <param name="password"></param>
        public void Login(string id, string password)
        {
            try
            {
                UserInfo ui = new UserInfo();
                ui.id = id;
                ui.password = password;
                try
                {
                    SetBasicInfo();
                }
                catch (IndexOutOfRangeException) { }
                catch (Exception ex) 
                {
                    throw ex;
                }

                this.userInfo = (UserInfo)GetCommandListener(CommandListenerType.userAuth).Select(ui);
                this.CommandManager = new CMDManager(logger, settingInfo, userInfo, myInfo);
            }
            catch (Exception)
            {
                proxyProvider.Dispose();
                throw;
            }
        }



        /// <summary>
        /// 로그인 정보를 제외한 기본정보들을 세팅(DB에서 메모리로 세팅) 
        /// 이 메서드를 실행하지 않으면 로그인 외에 할수 있는게 아무것도 없다
        /// </summary>
        public void SetBasicInfo() 
        {
            this.settingInfo = new SettingInfoProvider(GetCommandListener(CommandListenerType.workInfo)).GetCommonSetting();
            this.myInfo = new MyInfoProvider(GetCommandListener(CommandListenerType.myInfo)).GetMyInfo();
            if (CommandManager!=null)
            {
                CommandManager.myInfo = this.myInfo;
                CommandManager.SettingInfo = this.settingInfo;
            }
        }

        /// <summary>
        /// 커맨드리스너를 반환
        /// </summary>
        /// <param name="cmdListenerType"></param>
        /// <returns></returns>
        public ICommandListener GetCommandListener(CommandListenerType cmdListenerType) 
        {
            return CMDListenerFactory.GetCommandListener(cmdListenerType);
        }


        #region 검색
        
        #endregion
    }
    
}
