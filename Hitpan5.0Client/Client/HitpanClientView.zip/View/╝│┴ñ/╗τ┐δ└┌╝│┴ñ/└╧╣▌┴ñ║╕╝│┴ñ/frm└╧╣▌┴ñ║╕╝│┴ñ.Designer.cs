﻿namespace HitpanClientView.View.설정.사용자설정.일반정보설정
{
    partial class frm일반정보설정
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtInitialDate = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtHomePage = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtChairman = new System.Windows.Forms.TextBox();
            this.txtBusinessContents = new System.Windows.Forms.TextBox();
            this.txtBusinessType = new System.Windows.Forms.TextBox();
            this.txtSocialRegistryNumber = new System.Windows.Forms.TextBox();
            this.txtSubBusinessNumber = new System.Windows.Forms.TextBox();
            this.txtBusinessNumber = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtZipNumber = new System.Windows.Forms.TextBox();
            this.txtMyName = new System.Windows.Forms.TextBox();
            this.linkUser = new System.Windows.Forms.LinkLabel();
            this.linkLicence = new System.Windows.Forms.LinkLabel();
            this.rtxtETC = new System.Windows.Forms.RichTextBox();
            this.link관리정보설정 = new System.Windows.Forms.LinkLabel();
            this.link양식정보설정 = new System.Windows.Forms.LinkLabel();
            this.btn전자발행서버점검 = new System.Windows.Forms.Button();
            this.btnApply = new System.Windows.Forms.Button();
            this.btnOut = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "사용업체명";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "우편번호";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "주소";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "사업자번호";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(219, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "종사업장 번호";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(416, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "법인등록번호";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(62, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "업태";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(62, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "업종";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(50, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "대표자";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(62, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "전화";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(62, 256);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "팩스";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(38, 289);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "홈페이지";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(62, 356);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 12;
            this.label13.Text = "비고";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(50, 324);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 13;
            this.label14.Text = "이메일";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 480);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 12);
            this.label15.TabIndex = 14;
            this.label15.Text = "초기 이월 일자";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtInitialDate);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtHomePage);
            this.groupBox1.Controls.Add(this.txtFax);
            this.groupBox1.Controls.Add(this.txtPhone);
            this.groupBox1.Controls.Add(this.txtChairman);
            this.groupBox1.Controls.Add(this.txtBusinessContents);
            this.groupBox1.Controls.Add(this.txtBusinessType);
            this.groupBox1.Controls.Add(this.txtSocialRegistryNumber);
            this.groupBox1.Controls.Add(this.txtSubBusinessNumber);
            this.groupBox1.Controls.Add(this.txtBusinessNumber);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtZipNumber);
            this.groupBox1.Controls.Add(this.txtMyName);
            this.groupBox1.Controls.Add(this.linkUser);
            this.groupBox1.Controls.Add(this.linkLicence);
            this.groupBox1.Controls.Add(this.rtxtETC);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(629, 515);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // txtInitialDate
            // 
            this.txtInitialDate.Location = new System.Drawing.Point(115, 471);
            this.txtInitialDate.Name = "txtInitialDate";
            this.txtInitialDate.Size = new System.Drawing.Size(98, 21);
            this.txtInitialDate.TabIndex = 31;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(115, 315);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(508, 21);
            this.txtEmail.TabIndex = 30;
            // 
            // txtHomePage
            // 
            this.txtHomePage.Location = new System.Drawing.Point(115, 280);
            this.txtHomePage.Name = "txtHomePage";
            this.txtHomePage.Size = new System.Drawing.Size(508, 21);
            this.txtHomePage.TabIndex = 29;
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(115, 247);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(98, 21);
            this.txtFax.TabIndex = 28;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(115, 220);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(98, 21);
            this.txtPhone.TabIndex = 27;
            // 
            // txtChairman
            // 
            this.txtChairman.Location = new System.Drawing.Point(115, 184);
            this.txtChairman.Name = "txtChairman";
            this.txtChairman.Size = new System.Drawing.Size(98, 21);
            this.txtChairman.TabIndex = 26;
            // 
            // txtBusinessContents
            // 
            this.txtBusinessContents.Location = new System.Drawing.Point(115, 156);
            this.txtBusinessContents.Name = "txtBusinessContents";
            this.txtBusinessContents.Size = new System.Drawing.Size(289, 21);
            this.txtBusinessContents.TabIndex = 25;
            // 
            // txtBusinessType
            // 
            this.txtBusinessType.Location = new System.Drawing.Point(115, 129);
            this.txtBusinessType.Name = "txtBusinessType";
            this.txtBusinessType.Size = new System.Drawing.Size(289, 21);
            this.txtBusinessType.TabIndex = 24;
            // 
            // txtSocialRegistryNumber
            // 
            this.txtSocialRegistryNumber.Location = new System.Drawing.Point(499, 96);
            this.txtSocialRegistryNumber.Name = "txtSocialRegistryNumber";
            this.txtSocialRegistryNumber.Size = new System.Drawing.Size(124, 21);
            this.txtSocialRegistryNumber.TabIndex = 23;
            // 
            // txtSubBusinessNumber
            // 
            this.txtSubBusinessNumber.Location = new System.Drawing.Point(306, 96);
            this.txtSubBusinessNumber.Name = "txtSubBusinessNumber";
            this.txtSubBusinessNumber.Size = new System.Drawing.Size(98, 21);
            this.txtSubBusinessNumber.TabIndex = 22;
            // 
            // txtBusinessNumber
            // 
            this.txtBusinessNumber.Location = new System.Drawing.Point(115, 96);
            this.txtBusinessNumber.Name = "txtBusinessNumber";
            this.txtBusinessNumber.Size = new System.Drawing.Size(98, 21);
            this.txtBusinessNumber.TabIndex = 21;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(115, 69);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(508, 21);
            this.txtAddress.TabIndex = 20;
            // 
            // txtZipNumber
            // 
            this.txtZipNumber.Location = new System.Drawing.Point(115, 48);
            this.txtZipNumber.Name = "txtZipNumber";
            this.txtZipNumber.Size = new System.Drawing.Size(107, 21);
            this.txtZipNumber.TabIndex = 19;
            // 
            // txtMyName
            // 
            this.txtMyName.Location = new System.Drawing.Point(115, 16);
            this.txtMyName.Name = "txtMyName";
            this.txtMyName.Size = new System.Drawing.Size(508, 21);
            this.txtMyName.TabIndex = 18;
            // 
            // linkUser
            // 
            this.linkUser.AutoSize = true;
            this.linkUser.Location = new System.Drawing.Point(418, 165);
            this.linkUser.Name = "linkUser";
            this.linkUser.Size = new System.Drawing.Size(65, 12);
            this.linkUser.TabIndex = 17;
            this.linkUser.TabStop = true;
            this.linkUser.Text = "사용자관리";
            this.linkUser.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkUser_LinkClicked);
            // 
            // linkLicence
            // 
            this.linkLicence.AutoSize = true;
            this.linkLicence.Location = new System.Drawing.Point(418, 132);
            this.linkLicence.Name = "linkLicence";
            this.linkLicence.Size = new System.Drawing.Size(53, 12);
            this.linkLicence.TabIndex = 16;
            this.linkLicence.TabStop = true;
            this.linkLicence.Text = "허가번호";
            // 
            // rtxtETC
            // 
            this.rtxtETC.Location = new System.Drawing.Point(115, 353);
            this.rtxtETC.Name = "rtxtETC";
            this.rtxtETC.Size = new System.Drawing.Size(508, 107);
            this.rtxtETC.TabIndex = 15;
            this.rtxtETC.Text = "";
            // 
            // link관리정보설정
            // 
            this.link관리정보설정.AutoSize = true;
            this.link관리정보설정.Location = new System.Drawing.Point(125, 548);
            this.link관리정보설정.Name = "link관리정보설정";
            this.link관리정보설정.Size = new System.Drawing.Size(109, 12);
            this.link관리정보설정.TabIndex = 18;
            this.link관리정보설정.TabStop = true;
            this.link관리정보설정.Text = "관리정보설정으로..";
            // 
            // link양식정보설정
            // 
            this.link양식정보설정.AutoSize = true;
            this.link양식정보설정.Location = new System.Drawing.Point(10, 548);
            this.link양식정보설정.Name = "link양식정보설정";
            this.link양식정보설정.Size = new System.Drawing.Size(109, 12);
            this.link양식정보설정.TabIndex = 19;
            this.link양식정보설정.TabStop = true;
            this.link양식정보설정.Text = "양식정보설정으로..";
            // 
            // btn전자발행서버점검
            // 
            this.btn전자발행서버점검.Location = new System.Drawing.Point(285, 543);
            this.btn전자발행서버점검.Name = "btn전자발행서버점검";
            this.btn전자발행서버점검.Size = new System.Drawing.Size(117, 23);
            this.btn전자발행서버점검.TabIndex = 20;
            this.btn전자발행서버점검.Text = "전자발행서버 점검";
            this.btn전자발행서버점검.UseVisualStyleBackColor = true;
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(432, 543);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(96, 23);
            this.btnApply.TabIndex = 21;
            this.btnApply.Text = "적용";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(548, 543);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(95, 23);
            this.btnOut.TabIndex = 22;
            this.btnOut.Text = "나가기";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // frm일반정보설정
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 576);
            this.Controls.Add(this.btnOut);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.btn전자발행서버점검);
            this.Controls.Add(this.link양식정보설정);
            this.Controls.Add(this.link관리정보설정);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frm일반정보설정";
            this.Text = "frm일반정보설정";
            this.Load += new System.EventHandler(this.frm일반정보설정_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frm일반정보설정_MouseDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtInitialDate;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtHomePage;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtChairman;
        private System.Windows.Forms.TextBox txtBusinessContents;
        private System.Windows.Forms.TextBox txtBusinessType;
        private System.Windows.Forms.TextBox txtSocialRegistryNumber;
        private System.Windows.Forms.TextBox txtSubBusinessNumber;
        private System.Windows.Forms.TextBox txtBusinessNumber;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtZipNumber;
        private System.Windows.Forms.TextBox txtMyName;
        private System.Windows.Forms.LinkLabel linkUser;
        private System.Windows.Forms.LinkLabel linkLicence;
        private System.Windows.Forms.RichTextBox rtxtETC;
        private System.Windows.Forms.LinkLabel link관리정보설정;
        private System.Windows.Forms.LinkLabel link양식정보설정;
        private System.Windows.Forms.Button btn전자발행서버점검;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Button btnOut;
    }
}